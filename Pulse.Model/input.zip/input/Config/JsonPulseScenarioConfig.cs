﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MultiagentEngine.Map;
using Newtonsoft.Json.Linq;
using Pulse.Common;
using Pulse.Common.ConfigFramework;
using Pulse.Plugin.SimpleInfection;

namespace Pulse.Model.Config
{
    public class JsonPulseScenarioConfig : PulseScenarioConfig
    {
        public JsonPulseScenarioConfig(string fileName)
        {
            var configPath = AppDomain.CurrentDomain.BaseDirectory + "Config\\" + fileName;
            InitSenario(configPath);
        }

        private void InitSenario(string configPath)
        {
            var jsnClasses = JObject.Parse(File.ReadAllText(configPath));

            var dir = GetInputDir() + Path.DirectorySeparatorChar + jsnClasses["DataSubDirectory"].Value<string>() + Path.DirectorySeparatorChar;
            DataDir = new BaseConfigField<string>(dir);
            Name = new BaseConfigField<string>(jsnClasses["ScenarioName"].Value<string>());
            VisNiceName = new BaseConfigField<string>(jsnClasses["VisName"].Value<string>());
            TimeStep = new BaseConfigField<double>(jsnClasses["TimeStep"].Value<int>());
            ToSecondsMultiplier = new BaseConfigField<double>(jsnClasses["ToSecondsMultiplier"].Value<int>());
            TimeStart = new BaseConfigField<DateTime>(jsnClasses["TimeStart"].Value<DateTime>());
            InitialPopulation = new BaseConfigField<int>(jsnClasses["InitialPopulation"].Value<int>());
            PreferredCoordinates = new BaseConfigField<string>(jsnClasses["PreferredCoordinates"].Value<string>());

            SceneryBlock = new BaseConfigField<string>(jsnClasses["SimulationType"].Value<string>());

            MapPointMin = new BaseConfigField<Coords>(new Coords
            {
                X = jsnClasses["MapPointDL"]["X"].Value<int>(),
                Y = jsnClasses["MapPointDL"]["Y"].Value<int>()
            });
            MapPointMax = new BaseConfigField<Coords>(new Coords
            {
                X = jsnClasses["MapPointUR"]["X"].Value<int>(),
                Y = jsnClasses["MapPointUR"]["Y"].Value<int>()
            });
            MetersPerMapUnit = new BaseConfigField<double>(jsnClasses["ToMetersMultiplier"].Value<double>());
            GeoPointMin = new BaseConfigField<GeoCoords>(new GeoCoords
            {
                Lat = jsnClasses["GeoPointDL"]["Lat"].Value<double>(),
                Lon = jsnClasses["GeoPointDL"]["Lon"].Value<double>()
            });
            GeoPointMax = new BaseConfigField<GeoCoords>(new GeoCoords
            {
                Lat = jsnClasses["GeoPointUR"]["Lat"].Value<double>(),
                Lon = jsnClasses["GeoPointUR"]["Lon"].Value<double>()
            });

            Plugins = new BaseConfigField<string[]>(jsnClasses["ActivePlugins"].Values<string>().ToArray());
            PluginsConfig = new Dictionary<string, PluginScenarioConfig>();

            if (Plugins.Value.Contains("SimpleInfection"))
            {
                var simpleInfectionConfig = new SimpleInfectionScenarioConfig(this);
                simpleInfectionConfig.InfectionName = new BaseConfigField<string>(jsnClasses["Plugins"]["SimpleInfection"]["InfectionName"].Value<string>());
                simpleInfectionConfig.InfectionInitialization = new BaseConfigField<string>(jsnClasses["Plugins"]["SimpleInfection"]["InfectionInitialization"].Value<string>());
                PluginsConfig.Add(simpleInfectionConfig.Name.Value, simpleInfectionConfig);
            }
        }

        

        private static string GetInputDir()
        {
            #region  Deployed Assembly

            var assemblFile = System.Reflection.Assembly.GetExecutingAssembly().Location;
            var assenblDir = Path.GetDirectoryName(assemblFile);

            var dataAssemblyDirLocation = assenblDir + Path.DirectorySeparatorChar + "InputData" + Path.DirectorySeparatorChar;
            var isDataInAssemblyDir = Directory.Exists(dataAssemblyDirLocation);

            if (isDataInAssemblyDir)
                return dataAssemblyDirLocation;

            #endregion

            #region Visual Studio API

            var solutionDir = Directory.GetParent(assenblDir).Parent.Parent.FullName;
            var dataInVisualStudioLocation = solutionDir + Path.DirectorySeparatorChar + "Pulse.Model" +
                                             Path.DirectorySeparatorChar + "InputData" + Path.DirectorySeparatorChar;
            var isDataInVisualStudioDir = Directory.Exists(dataInVisualStudioLocation);
            
            if (isDataInVisualStudioDir)
                return dataInVisualStudioLocation;

            #endregion

            #region Visual Studio Visualizer

            var solutionDirVis = Directory.GetParent(assenblDir).Parent.Parent.Parent.Parent.FullName;
            var dataInVisualStudioLocationVis = solutionDirVis + Path.DirectorySeparatorChar + "Pulse.Model" +
                                             Path.DirectorySeparatorChar + "InputData";
            var isDataInVisualStudioDirVis = Directory.Exists(dataInVisualStudioLocationVis);
            
            if (isDataInVisualStudioDirVis)
                return dataInVisualStudioLocationVis;

            #endregion

            #region Hardcode @deprecated

            //            var staticPath = @"C:\work\Downloaded\MobileExtreme3\VirtualSociety.Model\InputData";
//            var isDataInStaticPath = Directory.Exists(staticPath);
//            if (isDataInStaticPath)
//                return staticPath;
            #endregion

            throw new Exception("Input Data directory not found");
        }
    }
}
